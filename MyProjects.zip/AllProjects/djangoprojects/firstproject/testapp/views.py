from django.shortcuts import render
from django.http import HttpResponse
from testapp.models import Employee
# Create your views here.

def greeting(request):
    s= " <h1> Hello !!! Welcome to testapp </h1> "
    s+= " <p> This is your Landing Page </p> "
    s+= " <p> This is a very beautiful Website. I hope you like it </p> "
    return HttpResponse(s)


def showContact(request):
    s= " <h1> Welcome to Contact Page </h1> "
    s+= " <p> Website: alpha.com </p> "
    s+= " <p> Mobile: 9999999999 </p> "
    s+= " <p> Email: something@gmail.com </p> "
    return HttpResponse(s)


def about(request):
    text= "This is an about page"
    return render(request, 'testapp/about.html', {'text':text})


def employee_info_view(request):
    employees= Employee.objects.all()
    data= {'employees':employees}
    res= render(request, 'testapp/employees.html',data)
    return(res)
