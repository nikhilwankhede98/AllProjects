from tkinter import *
from PIL import ImageTk, Image
import requests
import json


root=Tk()
root.title("Weather")
root.iconbitmap('C:/Users/MSETCL/Downloads/iconfinder_Home_131778.ico')
root.geometry("700x100")



#http://www.airnowapi.org/aq/observation/zipCode/current/?format=application/json&zipCode=89129&distance=5&API_KEY=6171A82E-26FA-45DA-8553-7F148E8CE942
#Create zipcode Lookup fn

def zipLookup():
    zip.get()
    
    try:
        api_request = requests.get("http://www.airnowapi.org/aq/observation/zipCode/current/?format=application/json&zipCode=" + zip.get() +"&distance=5&API_KEY=6171A82E-26FA-45DA-8553-7F148E8CE942")
        api = json.loads(api_request.content)
        city= api[0]['ReportingArea']
        quality= api[0]['AQI']
        category= api[0]['Category']['Name']

        if category =="Good":
            color ="#00e400"
        elif category =="Moderate":
            color ="#ffff00"
        elif category =="Unhealthy for Sensitive Groups":
            color ="#ff7e00"
        elif category =="Unhealthy":
            color ="#ff0000"
        elif category =="Very Unhealthy":
            color ="#8f3f97"
        elif category =="Hazardous":
            color ="#7e0023"    
        
        root.configure(background= color)
        
        '''myLabel1= Label(root, text=api[0]).pack()                       #related to ozone
        myLabel2= Label(root, text=api[0]['ReportingArea']).pack()      #only reporting area
        myLabel3= Label(root, text=api[0]['AQI']).pack()                #only api
        myLabel1= Label(root, text=api[0]['Category']['Name']).pack()  '''

        myLabel= Label(root, text=city + "Air Quality" + "  " + str(quality) + "  " + category, font=("Helvetica",20), bg=color,)
        myLabel.grid(row=1, column= 0,columnspan=2)

        myLabel

    except Exception as e:
        api = "Error..."

zip = Entry(root)
zip.grid(row=0, column=0, stick=W+E+N+S)

myButton= Button(root, text="Lookup Zipcode", command=zipLookup)
myButton.grid(row=0, column=1, stick=W+E+N+S)


'''myLabel1= Label(root, text=api[0]).pack()                       #related to ozone
myLabel2= Label(root, text=api[0]['ReportingArea']).pack()      #only reporting area
myLabel3= Label(root, text=api[0]['AQI']).pack()                #only api
myLabel1= Label(root, text=api[0]['Category']['Name']).pack()  '''

root.mainloop()

