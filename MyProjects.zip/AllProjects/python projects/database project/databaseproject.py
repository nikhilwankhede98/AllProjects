from tkinter import *
from PIL import ImageTk, Image
import sqlite3

root=Tk()
root.title("FRAMES")
root.iconbitmap('C:/Users/MSETCL/Downloads/iconfinder_Home_131778.ico')
root.geometry("400x400")


#Create a DB or connect to one
conn= sqlite3.connect('address_book.db')               #if not present then it will create this in our directory where we have been saving our codes

#Create cursor
c=conn.cursor()


#Create Table
'''c.execute("""CREATE TABLE addresses(
        first_name text,
        last_name text,
        address text,
        city text,
        state text,
        zipcode integer
        )""")
'''

#Delete a record

def delete():

    conn= sqlite3.connect('address_book.db')    
    c=conn.cursor()    
    
    c.execute("DELETE FROM addresses WHERE oid= " + delete_box.get())        #here tkinter accepted delete_box as integer and not as string still did the job
    delete_box.delete(0, END)   
        

    conn.commit()               
    conn.close() 



#Create submit_button_function

def submit():
    
    conn= sqlite3.connect('address_book.db')    #connect to created DB
    c=conn.cursor()             #Create cursor

    #Insert into Table
    c.execute("INSERT INTO addresses VALUES (:f_name, :l_name, :address, :city, :state, :zipcode)",
            {
                'f_name':f_name.get(),
                'l_name':l_name.get(),
                'address':address.get(),
                'city':city.get(),
                'state':state.get(),
                'zipcode':zipcode.get()
                }) 

    conn.commit()               #save changes
    conn.close()                #Close connections

   
    #Clear Text Boxes to add another values in it after entering one value
    f_name.delete(0, END)
    l_name.delete(0, END)
    address.delete(0, END)
    city.delete(0, END)
    state.delete(0, END)
    zipcode.delete(0, END)
    

#Create Save Changes Fn

def save():
    conn= sqlite3.connect('address_book.db')  
    c=conn.cursor()

    record_id= delete_box.get()
    c.execute("""UPDATE addresses SET
        first_name = :first,
        last_name = :last,
        address= :address,
        city= :city,
        state= :state,
        zipcode= :zipcode

        WHERE oid= :oid""",

        {'first': f_name_editor.get(),
         'last': l_name_editor.get(),
         'address': address_editor.get(),
         'city': city_editor.get(),
         'state': state_editor.get(),
         'zipcode': zipcode_editor.get(),
         'oid': record_id    
         })

    conn.commit()               
    conn.close()
    editor.destroy()

    



#Create Update record fn

def update():

    global editor
    editor=Tk()
    editor.title("edit records")
    editor.iconbitmap('C:/Users/MSETCL/Downloads/iconfinder_Home_131778.ico')
    editor.geometry("400x200")

    conn= sqlite3.connect('address_book.db')  
    c=conn.cursor()

    record_id= delete_box.get()
    c.execute("SELECT * FROM addresses WHERE oid = " + record_id)
    records=c.fetchall()                                                                        

    #Make the variables as global since they are used in save function also

    global f_name_editor
    global l_name_editor
    global address_editor 
    global city_editor
    global state_editor
    global zipcode_editor

    
    f_name_editor= Entry(editor, width=30)
    f_name_editor.grid(row=0, column=1, padx=20, pady=(10, 0))

    l_name_editor= Entry(editor, width=30)
    l_name_editor.grid(row=1, column=1, padx=20)

    address_editor= Entry(editor, width=30)
    address_editor.grid(row=2, column=1, padx=20)

    city_editor= Entry(editor, width=30)
    city_editor.grid(row=3, column=1, padx=20)

    state_editor= Entry(editor, width=30)
    state_editor.grid(row=4, column=1, padx=20)

    zipcode_editor= Entry(editor, width=30)
    zipcode_editor.grid(row=5, column=1, padx=20)

    

    f_name_label=Label(editor, text="First Name")
    f_name_label.grid(row=0, column=0, pady=(10,0))

    l_name_label=Label(editor, text="Last Name")
    l_name_label.grid(row=1, column=0)

    address_label=Label(editor, text="address")
    address_label.grid(row=2, column=0)

    city_label=Label(editor, text="City")
    city_label.grid(row=3, column=0)

    state_label=Label(editor, text="State")
    state_label.grid(row=4, column=0)

    zipcode_label=Label(editor, text="Zipcode")
    zipcode_label.grid(row=5, column=0)

    
    for record in records:
        f_name_editor.insert(0, record[0])
        l_name_editor.insert(0, record[1])
        address_editor.insert(0, record[2])
        city_editor.insert(0, record[3])
        state_editor.insert(0, record[4])
        zipcode_editor.insert(0, record[5])


    
    #Save Changes Button
    edit_btn=Button(editor, text=" Save changes",command=save)
    edit_btn.grid(row=6, column=0, columnspan=2, pady=20, padx=10, ipadx=140)
    


    
#Create query fn
def query():
    conn= sqlite3.connect('address_book.db')  
    c=conn.cursor()
    c.execute("SELECT *,oid from addresses")
    records=c.fetchall()                #you can fetch one, many(selective),all                                          
    #print(records)                     #prints on the command window

    #Loop through records and we can do whatever queries we want

    print_records=''
    for record in records:
        print_records+=str(record) + "\n"

    qry_label=Label(root, text= print_records)
    qry_label.grid(row=11, column=0, columnspan=2)

    print_records1=''
    for record in records:
        print_records1+= str(record[0]) +" " + str(record[1]) + "                         " + "\t" + str(record[6]) + "\n"
        
    qry_label=Label(root, text= print_records1)
    qry_label.grid(row=12, column=0, columnspan=2)

    conn.commit()               
    conn.close() 
    


#create text boxes to type info in the fields

f_name= Entry(root, width=30)
f_name.grid(row=0, column=1, padx=20, pady=(10, 0))

l_name= Entry(root, width=30)
l_name.grid(row=1, column=1, padx=20)

address= Entry(root, width=30)
address.grid(row=2, column=1, padx=20)

city= Entry(root, width=30)
city.grid(row=3, column=1, padx=20)

state= Entry(root, width=30)
state.grid(row=4, column=1, padx=20)


zipcode= Entry(root, width=30)
zipcode.grid(row=5, column=1, padx=20)

delete_box =Entry(root, width=30)
delete_box.grid(row=7, column=1, padx=20, pady=5)

#create text boxes labels

f_name_label=Label(root, text="First Name")
f_name_label.grid(row=0, column=0, pady=(10,0))

l_name_label=Label(root, text="Last Name")
l_name_label.grid(row=1, column=0)

address_label=Label(root, text="address")
address_label.grid(row=2, column=0)

city_label=Label(root, text="City")
city_label.grid(row=3, column=0)

state_label=Label(root, text="State")
state_label.grid(row=4, column=0)

zipcode_label=Label(root, text="Zipcode")
zipcode_label.grid(row=5, column=0)

delete_box_label=Label(root, text="ID no.")
delete_box_label.grid(row=7, column=0)

#Create submit button

submit_button=Button(root, text=" Add Records to Database", command=submit)
submit_button.grid(row=6, column=0, columnspan=2, pady=10, padx=10, ipadx=100)

#Create Query Button

qry_btn=Button(root, text="Show Records", command= query)
qry_btn.grid(row=10, column=0, columnspan=2, pady=10, padx=10, ipadx=137)


#Create Delete Record Button
del_btn=Button(root, text="Delete Record", command= delete)
del_btn.grid(row=8, column=0, columnspan=2, pady=10, padx=10, ipadx=136)

#Create Update Record Button

update_btn= Button(root, text=" Edit Record", command= update)
update_btn.grid(row=9, column=0, columnspan=2, pady=10, padx=10, ipadx=140)



#save changes
conn.commit()


#Close connections
conn.close()

root.mainloop()
